/*
*/

#include <Arduino.h>
#include <RB_LCD_HC.h>

RB_LCD_BP::RB_LCD_BP(Stream& dev) : serial(dev) {}

void RB_LCD_BP::Clear() {
    serial.println("AT+CLR");
}

void RB_LCD_BP::Backlight(byte val) {
    char buffer[3];
    itoa(val, buffer, 10);	
    serial.print("AT+BL=");
    serial.println(buffer);
}

void RB_LCD_BP::CurPos(byte r, byte c) {
    char buffer[5];
    sprintf(buffer, "%d,%d", r, c);
    serial.print("AT+RC=");
    serial.println(buffer);
}

void RB_LCD_BP::writeChar(byte val) {
    serial.print("AT+PR=");
    serial.write(val);
    serial.println();
}

void RB_LCD_BP::PrintChar(byte val) {
    serial.print("AT+PR=");
    serial.write(val);
    serial.println();
}

void RB_LCD_BP::writeChars(char chars[], byte num) {
    serial.print("AT+PR=");
    for (byte i=0; i<num; i++) {
        serial.write(chars[i]);
    }
    serial.println();
};

void RB_LCD_BP::Print(char chars[]) {
    serial.print("AT+PR=");
    serial.println(chars);
};

void RB_LCD_BP::setBaud9600() {
    char buffer[2];
    itoa(3, buffer, 10);	
    serial.print("AT+BR=");
    serial.println(buffer);
}

void RB_LCD_BP::setBaud19200() {
    char buffer[2];
    itoa(4, buffer, 10);	
    serial.print("AT+BR=");
    serial.println(buffer);
}

void RB_LCD_BP::setBaud57600() {
    char buffer[2];
    itoa(6, buffer, 10);	
    serial.print("AT+BR=");
    serial.println(buffer);
}

void RB_LCD_BP::writeUDC(byte addr, byte udc[]) {
    char buffer[4];
    itoa(addr, buffer, 10);	
    serial.print("AT+SC=");
    serial.print(buffer);
    for (byte i=0; i<8; i++) {
        sprintf(buffer, ",%d", udc[i]);	
        serial.print(buffer);
    }
    serial.println();
}

void RB_LCD_BP::DefCustChar(byte addr, byte udc[]) {
    char buffer[4];
    itoa(addr, buffer, 10);	
    serial.print("AT+SC=");
    serial.print(buffer);
    for (byte i=0; i<8; i++) {
        sprintf(buffer, ",%d", udc[i]);	
        serial.print(buffer);
    }
    serial.println();
}

void RB_LCD_BP::Contrast(byte val) {
    char buffer[4];
    itoa(val, buffer, 10);	
    serial.print("AT+CT=");
    serial.println(buffer);
}

void RB_LCD_BP::set16x2() {
}

void RB_LCD_BP::ClearError() {
}
