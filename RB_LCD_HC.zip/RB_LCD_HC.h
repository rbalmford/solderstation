/*
*/

#ifndef RB_LCD_HC_h
#define RB_LCD_HC_h

#include <Arduino.h>

class RB_LCD_BP {
  public:
    RB_LCD_BP(Stream& dev);
    void Clear();
    void Backlight(byte val);
    void CurPos(byte r, byte c);
    void writeChar(byte val);
    void PrintChar(byte val);
    void writeChars(char chars[], byte num);
    void Print(char chars[]);
    void setBaud9600();
    void setBaud19200();
    void setBaud57600();
    void writeUDC(byte addr, byte udc[]);
    void DefCustChar(byte addr, byte udc[]);
    void Contrast(byte val);
    void set16x2();
    void ClearError();
  private:
    Stream& serial; 
};

#endif
